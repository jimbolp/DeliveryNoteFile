﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tests
{
    public class ConnectionStrings
    {
        public string SqlServer { get; set; }

        public string SqlCe { get; set; }
    }
}
