﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tests.Models
{
    public class MultiPKObject
    {
        public Guid PK1 { get; set; }
        public int PK2 { get; set; }
        public string Text { get; set; }
    }
}
